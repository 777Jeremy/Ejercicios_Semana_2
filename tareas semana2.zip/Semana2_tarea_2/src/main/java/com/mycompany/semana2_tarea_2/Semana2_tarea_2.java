/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.semana2_tarea_2;

import Vista.Semana2_tarea_2_vista;
/**
 *
 * @author User
 */
public class Semana2_tarea_2 {

    public static void main(String[] args) {
        Semana2_tarea_2_vista ejem = new Semana2_tarea_2_vista();
        ejem.show();
    }
}
