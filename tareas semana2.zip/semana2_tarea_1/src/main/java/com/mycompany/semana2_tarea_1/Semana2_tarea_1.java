/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.semana2_tarea_1;
import Vista.Semana_2_tarea_1_vista;
/**
 *
 * @author User
 */
public class Semana2_tarea_1 {

    public static void main(String[] args) {
        Semana_2_tarea_1_vista ejem = new Semana_2_tarea_1_vista();
        ejem.show();
    }
}
